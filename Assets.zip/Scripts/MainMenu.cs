using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void SelectLevel(int lvl) {
        SceneManager.LoadScene(lvl);
    }
}
