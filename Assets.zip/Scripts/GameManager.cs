using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public void DefeatScreen() {
       GetComponent<Animator>().SetTrigger("Defeat"); 
    }

    public void WinScreen() {
       GetComponent<Animator>().SetTrigger("Win");
    }

    public void Retry() {
       StartCoroutine(RetryAnimation());
    }

    public void Menu() {
       StartCoroutine(MenuAnimation());
    }

    public void NextLevel() {
       StartCoroutine(NLAnimation());
    }

    public IEnumerator NLAnimation() {
        GetComponent<Animator>().SetTrigger("FadeIn");
        yield return new WaitForSeconds(1);
        if(SceneManager.GetActiveScene().buildIndex == 7) {
           SceneManager.LoadScene(0);
        } else {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
        }
    }

    public IEnumerator MenuAnimation() {
        GetComponent<Animator>().SetTrigger("FadeIn");
        yield return new WaitForSeconds(1);
        SceneManager.LoadScene(0);
    }

    public IEnumerator RetryAnimation() {
        GetComponent<Animator>().SetTrigger("FadeIn");
        yield return new WaitForSeconds(1);
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
