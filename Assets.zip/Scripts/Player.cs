using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public Transform gun;
    public GameObject bullet;
    public GameObject Explosion;
    public int bulletCount = 0;
    public AudioClip Shoot;
    public AudioClip Die;

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.Translate(0,Input.GetAxis("Vertical")*Time.deltaTime*3,0);
        transform.Rotate(0,0,-Input.GetAxis("Horizontal")*Time.deltaTime*120);
    }

    void Update() {
        if(Input.GetKeyDown(KeyCode.Space) && bulletCount < 6) {
           
           AudioSource.PlayClipAtPoint(Shoot, transform.position);
           bulletCount += 1;
           Instantiate(bullet, gun.position, transform.rotation);
           
        }
        if(GameObject.FindGameObjectsWithTag("Enemy").Length == 0) {
            GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>().WinScreen();
            enabled = false;
        }
    }

    void OnCollisionEnter2D (Collision2D col) {
        if(col.gameObject.tag == "Bullet") {
            AudioSource.PlayClipAtPoint(Die, transform.position);
            GameObject.FindGameObjectWithTag("GameController").GetComponent<GameManager>().DefeatScreen();
            Instantiate(Explosion, transform.position, transform.rotation);
            Destroy(gameObject);
        }
    }
}
