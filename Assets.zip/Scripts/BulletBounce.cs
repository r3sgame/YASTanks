using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBounce : MonoBehaviour
{
    public float speed;
    public bool isPlayerBullet;
    public AudioClip Hit;
    // Start is called before the first frame update
    void Start()
    {
        
        GetComponent<Rigidbody2D>().AddRelativeForce(new Vector2(0, speed));
        StartCoroutine(Die());
    }

    IEnumerator Die() {
      yield return new WaitForSeconds(3);
       if(isPlayerBullet) {
          GameObject.FindGameObjectWithTag("Player").GetComponent<Player>().bulletCount -= 1;
          
        }
        Destroy(gameObject);
    }
    void OnCollisionEnter2D (Collision2D col) {
        AudioSource.PlayClipAtPoint(Hit, transform.position);
        if(col.gameObject.tag == "Player" || col.gameObject.tag == "Enemy") {
            Destroy(gameObject);
        }
    }
}
