using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dummy : MonoBehaviour
{
    public GameObject Explosion;
    public AudioClip Die;
    
    void OnCollisionEnter2D (Collision2D col) {
        if(col.gameObject.tag == "Bullet") {
            if(col.gameObject.GetComponent<BulletBounce>().isPlayerBullet){
                AudioSource.PlayClipAtPoint(Die, transform.position);
                Instantiate(Explosion, transform.position, transform.rotation);
                Destroy(gameObject);
            }
        }
    }
}
