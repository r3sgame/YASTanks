using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour
{

    public GameObject bullet;
    public Transform gun;
    public GameObject Explosion;
    public AudioClip Die;
    
    void Start() {
        transform.Translate(0,1,0);
        StartCoroutine(Shoot());
    }

    void Update()
    {
        Vector3 offset = GameObject.FindGameObjectWithTag("Player").transform.position - transform.position;

transform.rotation = Quaternion.LookRotation(
                       Vector3.forward, // Keep z+ pointing straight into the screen.
                       offset           // Point y+ toward the target.
                     );
        
    }

    IEnumerator Shoot() {
        
        yield return new WaitForSeconds(3);
        Instantiate(bullet, gun.position, transform.rotation);
        
        StartCoroutine(Shoot());
    }
    void OnCollisionEnter2D (Collision2D col) {
        if(col.gameObject.tag == "Bullet") {
            if(col.gameObject.GetComponent<BulletBounce>().isPlayerBullet){
                AudioSource.PlayClipAtPoint(Die, transform.position);
                Instantiate(Explosion, transform.position, transform.rotation);
                Destroy(gameObject);
            }
        }
    }
}
